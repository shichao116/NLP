Problem set 6: Distributional semantics
===================