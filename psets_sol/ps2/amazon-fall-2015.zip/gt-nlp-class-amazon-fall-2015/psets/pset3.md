Problem set 3: Hidden Markov Models
============