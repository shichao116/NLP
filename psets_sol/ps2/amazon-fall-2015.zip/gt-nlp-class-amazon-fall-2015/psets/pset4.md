Problem set 4: Discriminative sequence labeling
============